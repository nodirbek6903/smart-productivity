
function App() {

  return (
    <>
     <h1 className="bg-red-500">hello world</h1>
    </>
  )
}

export default App
