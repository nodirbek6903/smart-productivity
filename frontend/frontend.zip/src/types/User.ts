export interface Role {
  _id?: string;
  name: string;
  description?: string;
  permissions?: string[];
}

export interface IUser {
  _id?: string;
  fullName?: string;
  email?: string;
  avatar?: string;
  role?: Role | string;
  department?: string;
  position?: string;
  token?: string;
}
